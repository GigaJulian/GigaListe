@echo off
title GigaListe – Server
echo.
echo  ======================================
echo   GigaListe wird gestartet
echo  ======================================
echo.
echo  Bitte warten...

REM Wechsle in den Ordner wo die BAT-Datei liegt
cd /d "%~dp0"

REM Pruefe ob Python verfuegbar ist
python --version >nul 2>&1
if %errorlevel% == 0 (
    echo  Server laeuft auf: http://localhost:8080
    echo  Schliesse dieses Fenster NICHT - sonst stoppt die App!
    echo.
    start "" "http://localhost:8080"
    python -m http.server 8080
) else (
    REM Versuche python3
    python3 --version >nul 2>&1
    if %errorlevel% == 0 (
        echo  Server laeuft auf: http://localhost:8080
        start "" "http://localhost:8080"
        python3 -m http.server 8080
    ) else (
        echo.
        echo  FEHLER: Python nicht gefunden!
        echo.
        echo  Bitte Python installieren von: https://python.org
        echo  Beim Installieren "Add Python to PATH" anhakenm
        echo.
        pause
    )
)
