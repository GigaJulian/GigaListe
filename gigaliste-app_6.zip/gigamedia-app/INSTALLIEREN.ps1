# GigaListe - Auto-Installer v3
# Benutzt eingebauten PowerShell HTTP-Server - keine externe Software noetig!

$AppName   = "GigaListe"
$AppFolder = Join-Path $env:LOCALAPPDATA "GigaListeApp"
$Port      = 8765
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

function Write-Step { param($m); Write-Host "  >> $m" -ForegroundColor Cyan }
function Write-Ok   { param($m); Write-Host "  OK  $m" -ForegroundColor Green }
function Write-Warn { param($m); Write-Host "  !!  $m" -ForegroundColor Yellow }
function Write-Fail { param($m); Write-Host "  XX  $m" -ForegroundColor Red }

Clear-Host
Write-Host ""
Write-Host "  =============================================" -ForegroundColor Blue
Write-Host "   $AppName - Installation" -ForegroundColor White
Write-Host "  =============================================" -ForegroundColor Blue
Write-Host ""

# --- 1. App-Ordner erstellen ------------------------------------
Write-Step "Erstelle App-Ordner: $AppFolder"
if (!(Test-Path $AppFolder)) {
    New-Item -ItemType Directory -Path $AppFolder -Force | Out-Null
}

# --- 2. App-Dateien kopieren ------------------------------------
Write-Step "Kopiere App-Dateien ..."
$files = @("index.html","manifest.json","sw.js","icon-192.svg","icon-512.svg","icon.ico")
$allOk = $true
foreach ($f in $files) {
    $src = Join-Path $ScriptDir $f
    if (Test-Path $src) {
        Copy-Item $src -Destination $AppFolder -Force
        Write-Ok "  $f"
    } else {
        Write-Warn "  $f nicht gefunden - bitte alle Dateien im selben Ordner lassen!"
        $allOk = $false
    }
}
if (-not $allOk) {
    Write-Host ""
    Write-Fail "Fehlende Dateien! Bitte ZIP erneut entpacken und alle Dateien zusammen lassen."
    Write-Host "  Druecke eine Taste ..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# --- 3. Server-Skript schreiben (reiner PowerShell HTTP-Server) -
Write-Step "Erstelle Server-Skript ..."
$serverPath = Join-Path $AppFolder "server.ps1"

$serverScript = 'param([int]$Port=8765, [string]$Root=".")'
$serverScript += "`r`n" + '$listener = New-Object System.Net.HttpListener'
$serverScript += "`r`n" + '$listener.Prefixes.Add("http://localhost:" + $Port + "/")'
$serverScript += "`r`n" + '$listener.Start()'
$serverScript += "`r`n" + 'Write-Host "Server laeuft auf http://localhost:' + ":$Port" + '" -ForegroundColor Green'
$serverScript += "`r`n" + 'while ($listener.IsListening) {'
$serverScript += "`r`n" + '  try {'
$serverScript += "`r`n" + '    $ctx = $listener.GetContext()'
$serverScript += "`r`n" + '    $req = $ctx.Request'
$serverScript += "`r`n" + '    $res = $ctx.Response'
$serverScript += "`r`n" + '    $path = $req.Url.LocalPath.TrimStart("/")'
$serverScript += "`r`n" + '    if ($path -eq "" -or $path -eq "/") { $path = "index.html" }'
$serverScript += "`r`n" + '    $file = Join-Path $Root $path'
$serverScript += "`r`n" + '    if (Test-Path $file -PathType Leaf) {'
$serverScript += "`r`n" + '      $ext = [System.IO.Path]::GetExtension($file).ToLower()'
$serverScript += "`r`n" + '      $mime = switch($ext) { ".html"{"text/html;charset=utf-8"} ".js"{"application/javascript"} ".json"{"application/json"} ".svg"{"image/svg+xml"} ".css"{"text/css"} default{"application/octet-stream"} }'
$serverScript += "`r`n" + '      $bytes = [System.IO.File]::ReadAllBytes($file)'
$serverScript += "`r`n" + '      $res.ContentType = $mime'
$serverScript += "`r`n" + '      $res.ContentLength64 = $bytes.Length'
$serverScript += "`r`n" + '      $res.OutputStream.Write($bytes, 0, $bytes.Length)'
$serverScript += "`r`n" + '    } else {'
$serverScript += "`r`n" + '      $bytes = [System.Text.Encoding]::UTF8.GetBytes("<h1>404</h1>")'
$serverScript += "`r`n" + '      $res.StatusCode = 404'
$serverScript += "`r`n" + '      $res.OutputStream.Write($bytes, 0, $bytes.Length)'
$serverScript += "`r`n" + '    }'
$serverScript += "`r`n" + '    $res.OutputStream.Close()'
$serverScript += "`r`n" + '  } catch { }'
$serverScript += "`r`n" + '}'

[System.IO.File]::WriteAllText($serverPath, $serverScript, [System.Text.Encoding]::UTF8)
Write-Ok "Server-Skript erstellt"

# --- 4. Launcher-Skript schreiben ------------------------------
Write-Step "Erstelle Launcher ..."
$launcherPath = Join-Path $AppFolder "launch.ps1"
$url = "http://localhost:$Port"

$launcher = '# GigaListe Launcher'
$launcher += "`r`n" + '$AppFolder = "' + $AppFolder + '"'
$launcher += "`r`n" + '$Port = ' + $Port
$launcher += "`r`n" + '$url  = "' + $url + '"'
$launcher += "`r`n" + '$serverScript = Join-Path $AppFolder "server.ps1"'
$launcher += "`r`n"
$launcher += "`r`n" + '# Pruefe ob Server schon laeuft'
$launcher += "`r`n" + 'function Test-Port {'
$launcher += "`r`n" + '  try { $t = New-Object System.Net.Sockets.TcpClient("localhost",$Port); $t.Close(); return $true } catch { return $false }'
$launcher += "`r`n" + '}'
$launcher += "`r`n"
$launcher += "`r`n" + 'if (-not (Test-Port)) {'
$launcher += "`r`n" + '  # Starte Server in neuem verstecktem PowerShell-Prozess'
$launcher += "`r`n" + '  $psi = New-Object System.Diagnostics.ProcessStartInfo "powershell.exe"'
$launcher += "`r`n" + '  $psi.Arguments = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$serverScript`" -Port $Port -Root `"$AppFolder`""'
$launcher += "`r`n" + '  $psi.WindowStyle = "Hidden"'
$launcher += "`r`n" + '  $psi.CreateNoWindow = $true'
$launcher += "`r`n" + '  [System.Diagnostics.Process]::Start($psi) | Out-Null'
$launcher += "`r`n"
$launcher += "`r`n" + '  # Warte bis Server bereit ist (max 8 Sekunden)'
$launcher += "`r`n" + '  $tries = 0'
$launcher += "`r`n" + '  while (-not (Test-Port) -and $tries -lt 16) { Start-Sleep -Milliseconds 500; $tries++ }'
$launcher += "`r`n" + '}'
$launcher += "`r`n"
$launcher += "`r`n" + '# Oeffne App in Chrome oder Edge im App-Modus (kein Browser-UI)'
$launcher += "`r`n" + '$chromePaths = @('
$launcher += "`r`n" + '  (Join-Path $env:LOCALAPPDATA "Google\Chrome\Application\chrome.exe"),'
$launcher += "`r`n" + '  (Join-Path $env:PROGRAMFILES "Google\Chrome\Application\chrome.exe"),'
$launcher += "`r`n" + '  (Join-Path ${env:PROGRAMFILES(X86)} "Google\Chrome\Application\chrome.exe")'
$launcher += "`r`n" + ')'
$launcher += "`r`n" + '$edgePaths = @('
$launcher += "`r`n" + '  (Join-Path $env:LOCALAPPDATA "Microsoft\Edge\Application\msedge.exe"),'
$launcher += "`r`n" + '  (Join-Path $env:PROGRAMFILES "Microsoft\Edge\Application\msedge.exe")'
$launcher += "`r`n" + ')'
$launcher += "`r`n" + '$launched = $false'
$launcher += "`r`n" + 'foreach ($p in $chromePaths) {'
$launcher += "`r`n" + '  if (Test-Path $p) { Start-Process $p "--app=$url --window-size=820,960 --window-position=100,50"; $launched=$true; break }'
$launcher += "`r`n" + '}'
$launcher += "`r`n" + 'if (-not $launched) {'
$launcher += "`r`n" + '  foreach ($p in $edgePaths) {'
$launcher += "`r`n" + '    if (Test-Path $p) { Start-Process $p "--app=$url --window-size=820,960 --window-position=100,50"; $launched=$true; break }'
$launcher += "`r`n" + '  }'
$launcher += "`r`n" + '}'
$launcher += "`r`n" + 'if (-not $launched) { Start-Process $url }'

[System.IO.File]::WriteAllText($launcherPath, $launcher, [System.Text.Encoding]::UTF8)
Write-Ok "Launcher erstellt"

# --- 5. ICO-Icon Pfad setzen ------------------------------------
$icoPath = Join-Path $AppFolder "icon.ico"

# --- 6. Shortcuts erstellen ------------------------------------
Write-Step "Erstelle Verknuepfungen ..."
$wsh = New-Object -ComObject WScript.Shell
$psArgs = "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcherPath`""

# Desktop
$desktop = [Environment]::GetFolderPath("Desktop")
$sc = $wsh.CreateShortcut((Join-Path $desktop "$AppName.lnk"))
$sc.TargetPath       = "powershell.exe"
$sc.Arguments        = $psArgs
$sc.WorkingDirectory = $AppFolder
$sc.Description      = $AppName
$sc.WindowStyle      = 7
if (Test-Path $icoPath) { $sc.IconLocation = "$icoPath,0" }
$sc.Save()
Write-Ok "Desktop-Icon: $AppName"

# Startmenue
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$sc2 = $wsh.CreateShortcut((Join-Path $startMenu "$AppName.lnk"))
$sc2.TargetPath       = "powershell.exe"
$sc2.Arguments        = $psArgs
$sc2.WorkingDirectory = $AppFolder
$sc2.Description      = $AppName
$sc2.WindowStyle      = 7
if (Test-Path $icoPath) { $sc2.IconLocation = "$icoPath,0" }
$sc2.Save()
Write-Ok "Startmenue-Eintrag erstellt"

# --- 7. Autostart optional -------------------------------------
Write-Host ""
Write-Host "  Autostart beim Windows-Start? (j/n): " -NoNewline -ForegroundColor White
$ans = Read-Host
if ($ans -match "^[jJ]") {
    $startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
    $sc3 = $wsh.CreateShortcut((Join-Path $startup "$AppName.lnk"))
    $sc3.TargetPath       = "powershell.exe"
    $sc3.Arguments        = $psArgs
    $sc3.WorkingDirectory = $AppFolder
    $sc3.Description      = $AppName
    $sc3.WindowStyle      = 7
    if (Test-Path $icoPath) { $sc3.IconLocation = "$icoPath,0" }
    $sc3.Save()
    Write-Ok "Autostart aktiviert"
}

# --- 8. Fertig -------------------------------------------------
Write-Host ""
Write-Host "  =============================================" -ForegroundColor Green
Write-Host "   Fertig! App ist installiert." -ForegroundColor Green
Write-Host "  =============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Starten: Desktop-Doppelklick auf '$AppName'" -ForegroundColor Cyan
Write-Host ""

# IP fuer Handy-Zugriff
try {
    $ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
        $_.InterfaceAlias -notmatch "Loopback" -and $_.IPAddress -notmatch "^169"
    } | Select-Object -First 1).IPAddress
    if ($ip) {
        Write-Host "  Handy-Zugriff (selbes WLAN): http://${ip}:${Port}" -ForegroundColor Yellow
        Write-Host "  (Erst Desktop-App starten, dann Handy-URL aufrufen)" -ForegroundColor Yellow
        Write-Host ""
    }
} catch {}

Write-Host "  App jetzt direkt starten? (j/n): " -NoNewline -ForegroundColor White
$go = Read-Host
if ($go -match "^[jJ]") {
    & powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File "$launcherPath"
    Start-Sleep -Seconds 1
    Write-Ok "Gestartet! Fenster erscheint in Kuerze."
}

Write-Host ""
Write-Host "  Druecke eine Taste zum Beenden ..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
