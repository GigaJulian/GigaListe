@echo off
:: GigaListe – Installer Starter
:: Einfach doppelklicken!
title GigaListe Installer

:: PowerShell-Ausfuehrungsrichtlinie umgehen und Installer starten
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLIEREN.ps1"

:: Falls PowerShell nicht gefunden
if %errorlevel% neq 0 (
    echo.
    echo  Fehler beim Starten. Bitte INSTALLIEREN.ps1 mit
    echo  Rechtsklick -> "Mit PowerShell ausfuehren" starten.
    echo.
    pause
)
